
package festinese.guadalupe.pkg1p.pkg122;

public enum TipoAgua {
    DULCE,
    SALADA
}
