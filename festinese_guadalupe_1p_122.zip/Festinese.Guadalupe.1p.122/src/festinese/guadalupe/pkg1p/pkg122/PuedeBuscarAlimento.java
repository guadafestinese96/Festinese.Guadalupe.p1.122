
package festinese.guadalupe.pkg1p.pkg122;

public interface PuedeBuscarAlimento {
    String buscarAlimento();
}
