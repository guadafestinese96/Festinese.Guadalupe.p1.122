
package festineseguadalupepkg1ppkg122;

public enum TipoAgua {
    DULCE,
    SALADA
}
