
package festineseguadalupepkg1ppkg122;

public interface PuedeNadar {
    String nadar();
}
