
package festineseguadalupepkg1ppkg122;

public interface PuedeBuscarAlimento {
    String buscarAlimento();
}
